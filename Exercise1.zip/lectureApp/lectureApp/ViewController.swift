//
//  ViewController.swift
//  lectureApp
//
//  Created by Clemens Stift on 12.11.18.
//  Copyright © 2018 Clemens Stift. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userTextEntry: UITextField!
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var okButton: UIButton!
    
    @IBAction func clickEventListener(_ sender: Any) {
        topLabel.text = "Hallo " + userTextEntry.text!;
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
